# 新的游戏-02

这是一个 Phaser 3 模板，新增了一个基于生成图像的可爱动物三消小游戏示例。

说明：
- 动物圖標位於 assets/images/animal-*.png，已由 AI 生成並拆分。
- 关卡配置在 src/config.js 的 window.GENSTORY_LEVELS 中，可按需调整。
- 场景：MenuScene -> LevelSelectScene -> Match3Scene -> ResultScene。

如何运行：
1. 在本地启动一个小型静态服务器（例如：python -m http.server）
2. 在浏览器打开 index.html

后续：可替换图标、加入音效、调整难度或拓展道具。
