---
title: "新的游戏-02"
type: phaser-game
status: draft
---

# 新的游戏-02

这是一个由 GenStory.cc 模板创建的作品。
