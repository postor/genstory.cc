window.GENSTORY_PHASER_CONFIG = {
  type: Phaser.AUTO,
  parent: "game",
  width: 960,
  height: 540,
  backgroundColor: "#08111f",
  physics: {
    default: "arcade",
    arcade: { gravity: { y: 900 }, debug: false },
  },
};

// 可爱动物三消：6 种动物（对应 assets/images/animal-*.png）
window.GENSTORY_ANIMALS = [
  { id: "cat",     key: "animal-cat",     name: "橙猫",   color: 0xff9f43 },
  { id: "frog",    key: "animal-frog",    name: "绿蛙",   color: 0x10b981 },
  { id: "bunny",   key: "animal-bunny",   name: "粉兔",   color: 0xf472b6 },
  { id: "penguin", key: "animal-penguin", name: "蓝企鹅", color: 0x3b82f6 },
  { id: "pig",     key: "animal-pig",     name: "红猪",   color: 0xef4444 },
  { id: "chick",   key: "animal-chick",   name: "黄雏鸟", color: 0xfacc15 }
];

// 多关卡（列固定 8；rows/moves/colors 随关卡提升）
window.GENSTORY_LEVELS = [
  { level: 1, rows: 6, cols: 8, colors: 4, moves: 20, targetScore: 300 },
  { level: 2, rows: 7, cols: 8, colors: 4, moves: 22, targetScore: 600 },
  { level: 3, rows: 7, cols: 8, colors: 5, moves: 22, targetScore: 900 },
  { level: 4, rows: 8, cols: 8, colors: 5, moves: 24, targetScore: 1300 },
  { level: 5, rows: 8, cols: 8, colors: 6, moves: 26, targetScore: 1800 },
  { level: 6, rows: 9, cols: 8, colors: 6, moves: 28, targetScore: 2400 }
];
