(function (global) {
  if (global.__GENSTORY_PHASER_ASSET_BRIDGE__) return;

  const assetUrls = global.GENSTORY_ASSET_URLS || {};
  const preview = new URLSearchParams(global.location.search).get("preview") === "1";

  function normalize(path) {
    return String(path).split(/[?#]/, 1)[0].replace(/^.?\//, "").replace(/^\/+/, "");
  }

  function resolve(path) {
    if (!preview || typeof path !== "string") return path;
    return assetUrls[normalize(path)] || path;
  }

  global.GENSTORY_PREVIEW = preview;
  global.GenStoryAssets = Object.freeze({ isPreview: preview, resolve });
})(window);
