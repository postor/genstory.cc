const gameConfig = {
  ...window.GENSTORY_PHASER_CONFIG,
  scene: [MenuScene, LevelSelectScene, Match3Scene, ResultScene, TestGameScene],
};

new Phaser.Game(gameConfig);
