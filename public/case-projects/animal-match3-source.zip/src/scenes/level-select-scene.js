/**
 * LevelSelectScene - 列出关卡并进入 Match3Scene
 */
class LevelSelectScene extends Phaser.Scene {
  constructor() { super("LevelSelectScene"); }

  create() {
    this.cameras.main.setBackgroundColor("#0f172a");
    this.add.text(480, 64, "选择关卡", { fontSize: "32px", color: "#f8fafc" }).setOrigin(0.5);

    const levels = window.GENSTORY_LEVELS || [];
    const startY = 140;
    const gapY = 60;
    levels.forEach((lvl, idx) => {
      const y = startY + idx * gapY;
      const btn = this.add.rectangle(480, y, 520, 44, 0x334155).setInteractive({ useHandCursor: true });
      const label = this.add.text(480, y, `第 ${lvl.level} 关 — 目标: ${lvl.targetScore} 分，步数: ${lvl.moves}`, { fontSize: "18px", color: "#f8fafc" }).setOrigin(0.5);
      btn.on("pointerup", () => this.scene.start("Match3Scene", { levelIndex: idx }));
      void label;
    });

    const back = this.add.text(40, 480, "返回菜单", { fontSize: "16px", color: "#cbd5e1" }).setInteractive({ useHandCursor: true });
    back.on("pointerup", () => this.scene.start("MenuScene"));
  }
}
