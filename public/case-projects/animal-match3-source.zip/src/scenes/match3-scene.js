/**
 * Match3Scene - 三消核心（响应式）：
 * - 返回关卡列表按钮（右上角）
 * - 棋盘放在 container 内并根据窗口/画布大小自适应缩放，避免遮挡
 * - 选中由描边（Graphics）标记，不再用放大，避免视觉放大问题
 * - 保持原有交换/匹配/消除/下落/补充/连锁/死局洗牌/胜负逻辑
 */
class Match3Scene extends Phaser.Scene {
  constructor() { super("Match3Scene"); }

  init(data) {
    this.levelIndex = (data && data.levelIndex) || 0;
  }

  preload() {
    // 加载动物图标（使用项目的资源解析桥接）
    (window.GENSTORY_ANIMALS || []).forEach(a => this.load.image(a.key, GenStoryAssets.resolve(`assets/images/${a.key}.png`)));
  }

  create() {
    const level = (window.GENSTORY_LEVELS && window.GENSTORY_LEVELS[this.levelIndex]) || window.GENSTORY_LEVELS[0];
    this.rows = level.rows; this.cols = level.cols; this.maxColors = level.colors; this.movesLeft = level.moves; this.targetScore = level.targetScore;
    this.score = 0;
    this.tileSize = 64; // logical tile size before scaling

    // HUD
    this.cameras.main.setBackgroundColor('#071427');
    this.add.text(24, 16, `第 ${level.level} 关`, { fontSize: '20px', color: '#f8fafc' });
    this.scoreText = this.add.text(24, 44, `得分: ${this.score}`, { fontSize: '16px', color: '#cbd5e1' });
    this.movesText = this.add.text(24, 68, `步数: ${this.movesLeft}`, { fontSize: '16px', color: '#cbd5e1' });
    this.targetText = this.add.text(24, 92, `目标: ${this.targetScore}`, { fontSize: '16px', color: '#cbd5e1' });

    // 返回关卡列表按钮（右上角，始终在 HUD 外侧，不随棋盘缩放）
    const backBtn = this.add.rectangle(this.game.config.width - 20, 16, 120, 40, 0x374151).setOrigin(1, 0).setInteractive({ useHandCursor: true });
    this.add.text(this.game.config.width - 80, 36, '返回关卡', { fontSize: '14px', color: '#ffffff' }).setOrigin(0.5, 0.5);
    backBtn.on('pointerup', () => this.scene.start('LevelSelectScene'));

    // board origin = top-left of where board container will be placed
    // keep some top margin for HUD; place board below HUD
    this.boardOriginX = 24;
    this.boardOriginY = 140;

    // a container for the board so we can scale it uniformly
    this.boardContainer = this.add.container(this.boardOriginX, this.boardOriginY);

    // palette indices mapping to animal keys
    const animals = (window.GENSTORY_ANIMALS || []).slice(0, this.maxColors);
    this.palette = animals.map(a => a.key);

    // board data
    this.board = [];
    for (let r = 0; r < this.rows; r++) this.board[r] = new Array(this.cols).fill(null);

    // selection marker (Graphics) placed inside container so it scales with board
    this.selectionMarker = this.add.graphics();
    // add marker to container so it scales with the board; marker depth set low so sprites render above
    this.boardContainer.add(this.selectionMarker);
    this.selectionMarker.setDepth(-1);

    // create sprites inside container (initially unscaled)
    this.tilesGroup = this.add.group();

    this.generateInitialBoard();

    // compute scale and apply
    this.applyBoardScale();

    // listen for resize to recompute scale
    if (this.scale && this.scale.on) {
      this.scale.on('resize', () => this.applyBoardScale());
    }

    // input handling (works with objects inside container)
    this.input.on('gameobjectdown', this.onObjectDown, this);

    this.busy = false;
  }

  // compute local (container) coordinates for a cell
  cellLocalXY(row, col) {
    const x = col * this.tileSize + this.tileSize / 2;
    const y = row * this.tileSize + this.tileSize / 2;
    return { x, y };
  }

  // global helper maintained for older code compatibility
  cellXY(row, col) { return this.cellLocalXY(row, col); }

  // scale the board container to fit available area and center it horizontally
  applyBoardScale() {
    const maxBoardW = this.game.config.width - 48; // left/right margins
    const maxBoardH = this.game.config.height - 180; // reserve HUD/footer
    const rawW = this.cols * this.tileSize;
    const rawH = this.rows * this.tileSize;
    const scale = Math.min(1, maxBoardW / rawW, maxBoardH / rawH);
    this.boardContainer.setScale(scale);
    // center board horizontally within the game area with left margin considered
    const boardDisplayW = rawW * scale;
    const x = Math.max(24, Math.round((this.game.config.width - boardDisplayW) / 2));
    this.boardContainer.x = x;
    // keep board at boardOriginY
    this.boardContainer.y = this.boardOriginY;
  }

  generateInitialBoard() {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        let attempts = 0;
        do {
          const type = Phaser.Math.Between(0, this.palette.length - 1);
          this.board[r][c] = { type };
          attempts++;
        } while (this.hasMatchAt(r, c) && attempts < 10);
      }
    }
    // render sprites into container
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) this.createTileSprite(r, c);
    }
  }

  createTileSprite(row, col) {
    const local = this.cellLocalXY(row, col);
    const type = this.board[row][col].type;
    const key = this.palette[type];
    const sprite = this.add.image(local.x, local.y, key).setDisplaySize(this.tileSize - 8, this.tileSize - 8).setInteractive();
    sprite.__row = row; sprite.__col = col; sprite.__type = type;
    // add sprite to container so it participates in the uniform scaling
    this.boardContainer.add(sprite);
    this.board[row][col].sprite = sprite;
    this.tilesGroup.add(sprite);
  }

  hasMatchAt(r, c) {
    const type = this.board[r][c].type;
    let count = 1; let col = c - 1;
    while (col >= 0 && this.board[r][col] && this.board[r][col].type === type) { count++; col--; }
    col = c + 1; while (col < this.cols && this.board[r][col] && this.board[r][col].type === type) { count++; col++; }
    if (count >= 3) return true;
    count = 1; let row = r - 1;
    while (row >= 0 && this.board[row][c] && this.board[row][c].type === type) { count++; row--; }
    row = r + 1; while (row < this.rows && this.board[row][c] && this.board[row][c].type === type) { count++; row++; }
    return count >= 3;
  }

  onObjectDown(pointer, gameObject) {
    if (this.busy) return;
    if (!gameObject || !gameObject.__row) return; // ignore non-tile clicks
    if (this.selected) {
      const s = this.selected; const t = gameObject;
      if (s === t) { this.clearSelection(); return; }
      const dr = Math.abs(s.__row - t.__row); const dc = Math.abs(s.__col - t.__col);
      if ((dr === 1 && dc === 0) || (dr === 0 && dc === 1)) {
        this.attemptSwap(s, t);
      } else {
        this.clearSelection(); this.selectTile(t);
      }
    } else {
      this.selectTile(gameObject);
    }
  }

  // select by drawing a stroked rounded rect in container-local coords; marker is a child of boardContainer
  selectTile(sprite) {
    this.clearSelection();
    this.selected = sprite;
    // draw marker inside container so it scales with board
    if (!this.selectionMarker) this.selectionMarker = this.add.graphics();
    this.selectionMarker.clear();
    this.selectionMarker.lineStyle(3, 0xffe66b, 1);
    const half = this.tileSize / 2;
    // sprite.x/y are local positions inside container
    this.selectionMarker.strokeRoundedRect(sprite.x - half - 6, sprite.y - half - 6, this.tileSize + 12, this.tileSize + 12, 8);
    // ensure marker is below sprites visually: set depth lower than tiles (global)
    this.selectionMarker.setDepth(-1);
    // ensure marker is parented to the container so it scales together
    if (this.selectionMarker.parentContainer !== this.boardContainer) {
      this.boardContainer.add(this.selectionMarker);
    }
  }

  clearSelection() {
    if (this.selected) this.selected = null;
    if (this.selectionMarker) this.selectionMarker.clear();
  }

  attemptSwap(s1, s2) {
    this.busy = true;
    const r1 = s1.__row, c1 = s1.__col, r2 = s2.__row, c2 = s2.__col;
    this.swapBoardPositions(r1, c1, r2, c2);
    const p1 = this.cellLocalXY(r1, c1), p2 = this.cellLocalXY(r2, c2);
    this.tweens.add({ targets: s1, x: p2.x, y: p2.y, duration: 160 });
    this.tweens.add({ targets: s2, x: p1.x, y: p1.y, duration: 160, onComplete: () => {
      const matches = this.findAllMatches();
      if (matches.length > 0) {
        this.movesLeft -= 1; if (this.movesText) this.movesText.setText(`步数: ${this.movesLeft}`);
        this.processMatches(matches).then(() => { this.busy = false; this.clearSelection(); this.checkWinLose(); });
      } else {
        // swap back
        this.swapBoardPositions(r1, c1, r2, c2);
        this.tweens.add({ targets: s1, x: p1.x, y: p1.y, duration: 160 });
        this.tweens.add({ targets: s2, x: p2.x, y: p2.y, duration: 160, onComplete: () => { this.busy = false; this.clearSelection(); } });
      }
    }});
  }

  swapBoardPositions(r1, c1, r2, c2) {
    const a = this.board[r1][c1]; const b = this.board[r2][c2];
    this.board[r1][c1] = b; this.board[r2][c2] = a;
    if (this.board[r1][c1] && this.board[r1][c1].sprite) { this.board[r1][c1].sprite.__row = r1; this.board[r1][c1].sprite.__col = c1; }
    if (this.board[r2][c2] && this.board[r2][c2].sprite) { this.board[r2][c2].sprite.__row = r2; this.board[r2][c2].sprite.__col = c2; }
  }

  findAllMatches() {
    const matches = [];
    const used = Array.from({ length: this.rows }, () => Array(this.cols).fill(false));
    // horizontal detection
    for (let r = 0; r < this.rows; r++) {
      let start = 0;
      for (let c = 1; c <= this.cols; c++) {
        const prevType = (c - 1 >= 0) ? this.board[r][c - 1].type : null;
        const curType = (c < this.cols) ? this.board[r][c].type : null;
        if (c === this.cols || curType !== prevType) {
          const len = c - start;
          if (prevType !== null && len >= 3) {
            const match = [];
            for (let k = start; k < c; k++) { match.push({ r, c: k }); used[r][k] = true; }
            matches.push(match);
          }
          start = c;
        }
      }
    }
    // vertical detection
    for (let c = 0; c < this.cols; c++) {
      let start = 0;
      for (let r = 1; r <= this.rows; r++) {
        const prevType = (r - 1 >= 0) ? this.board[r - 1][c].type : null;
        const curType = (r < this.rows) ? this.board[r][c].type : null;
        if (r === this.rows || curType !== prevType) {
          const len = r - start;
          if (prevType !== null && len >= 3) {
            const match = [];
            for (let k = start; k < r; k++) { if (!used[k][c]) match.push({ r: k, c }); }
            if (match.length > 0) matches.push(match);
          }
          start = r;
        }
      }
    }
    return matches;
  }

  async processMatches(matches) {
    const posSet = new Set();
    matches.forEach(group => group.forEach(p => posSet.add(`${p.r},${p.c}`)));
    const positions = Array.from(posSet).map(s => { const [r,c] = s.split(',').map(Number); return { r, c }; });
    for (const p of positions) {
      const cell = this.board[p.r][p.c];
      if (cell && cell.sprite) this.tweens.add({ targets: cell.sprite, alpha: 0, scale: 0.2, duration: 220 });
    }
    const gained = positions.length * 100; this.score += gained; if (this.scoreText) this.scoreText.setText(`得分: ${this.score}`);
    await this.wait(260);
    positions.forEach(p => { const cell = this.board[p.r][p.c]; if (cell && cell.sprite) cell.sprite.destroy(); this.board[p.r][p.c] = null; });
    await this.collapseAndRefill();
    const newMatches = this.findAllMatches(); if (newMatches.length > 0) await this.processMatches(newMatches);
  }

  async collapseAndRefill() {
    for (let c = 0; c < this.cols; c++) {
      let writeRow = this.rows - 1;
      for (let r = this.rows - 1; r >= 0; r--) {
        if (this.board[r][c] !== null) {
          if (writeRow !== r) {
            this.board[writeRow][c] = this.board[r][c];
            if (this.board[writeRow][c].sprite) {
              this.board[writeRow][c].sprite.__row = writeRow; this.board[writeRow][c].sprite.__col = c;
              const dest = this.cellLocalXY(writeRow, c);
              this.tweens.add({ targets: this.board[writeRow][c].sprite, x: dest.x, y: dest.y, duration: 160 });
            }
            this.board[r][c] = null;
          }
          writeRow--;
        }
      }
      for (let r = writeRow; r >= 0; r--) {
        const type = Phaser.Math.Between(0, this.palette.length - 1);
        const key = this.palette[type];
        const spawnY = -80 - (this.rows - r) * 16; // container-local spawn above top
        const { x } = this.cellLocalXY(r, c);
        const sprite = this.add.image(x, spawnY, key).setDisplaySize(this.tileSize - 8, this.tileSize - 8).setInteractive();
        sprite.__row = r; sprite.__col = c; sprite.__type = type;
        this.boardContainer.add(sprite);
        this.board[r][c] = { type, sprite };
        this.tweens.add({ targets: sprite, x: this.cellLocalXY(r, c).x, y: this.cellLocalXY(r, c).y, duration: 220 });
      }
    }
    await this.wait(240);
  }

  wait(ms) { return new Promise(resolve => this.time.delayedCall(ms, () => resolve())); }

  checkWinLose() {
    if (this.score >= this.targetScore) { this.scene.start('ResultScene', { success: true, score: this.score, levelIndex: this.levelIndex }); return; }
    if (this.movesLeft <= 0) { this.scene.start('ResultScene', { success: false, score: this.score, levelIndex: this.levelIndex }); return; }
    if (this.isDeadlocked()) this.shuffleBoard();
  }

  isDeadlocked() {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const dirs = [[1,0],[0,1]];
        for (const d of dirs) {
          const nr = r + d[0], nc = c + d[1];
          if (nr < this.rows && nc < this.cols) {
            this.swapBoardPositions(r,c,nr,nc);
            const matches = this.findAllMatches();
            this.swapBoardPositions(r,c,nr,nc);
            if (matches.length > 0) return false;
          }
        }
      }
    }
    return true;
  }

  shuffleBoard() {
    const types = [];
    for (let r = 0; r < this.rows; r++) for (let c = 0; c < this.cols; c++) types.push(this.board[r][c].type);
    Phaser.Utils.Array.Shuffle(types);
    for (let r = 0, k = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++, k++) {
        const cell = this.board[r][c]; cell.type = types[k]; const key = this.palette[cell.type]; if (cell && cell.sprite) { cell.sprite.setTexture(key); cell.sprite.__type = cell.type; }
      }
    }
    if (this.findAllMatches().length > 0) this.shuffleBoard();
  }
}
