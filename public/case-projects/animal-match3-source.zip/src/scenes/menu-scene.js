/**
 * MenuScene - 跳转到关卡选择
 */
class MenuScene extends Phaser.Scene {
  constructor() { super("MenuScene"); }

  preload() {
    // future hooks
  }

  create() {
    this.cameras.main.setBackgroundColor("#101b35");
    this.add.text(480, 110, "新的游戏-02", { fontFamily: "Inter, sans-serif", fontSize: "42px", color: "#f8fafc" }).setOrigin(0.5);
    this.add.text(480, 170, "可爱动物三消", { fontSize: "20px", color: "#a5b4fc" }).setOrigin(0.5);

    const startBtn = this.add.rectangle(480, 260, 260, 64, 0x4f46e5, 1).setInteractive({ useHandCursor: true });
    const startLabel = this.add.text(480, 260, "开始游戏", { fontSize: "24px", color: "#fff" }).setOrigin(0.5);
    startBtn.on("pointerup", () => this.scene.start("LevelSelectScene"));

    const tutorial = this.add.text(480, 360, "点击相邻图标交换，连成 3 个或以上消除。", { fontSize: "16px", color: "#cbd5e1" }).setOrigin(0.5);

    this.input.keyboard.once("keydown-ENTER", () => this.scene.start("LevelSelectScene"));
    void startLabel; void tutorial;
  }
}
