/**
 * ResultScene - 关卡结算
 */
class ResultScene extends Phaser.Scene {
  constructor() { super("ResultScene"); }

  init(data) {
    this.success = data.success; this.score = data.score || 0; this.levelIndex = data.levelIndex || 0;
  }

  create() {
    this.cameras.main.setBackgroundColor('#071427');
    const title = this.success ? '关卡通过！' : '挑战失败';
    this.add.text(480, 120, title, { fontSize: '36px', color: '#f8fafc' }).setOrigin(0.5);
    this.add.text(480, 180, `得分: ${this.score}`, { fontSize: '20px', color: '#cbd5e1' }).setOrigin(0.5);

    const y = 260;
    if (this.success) {
      const nextBtn = this.add.rectangle(480, y, 320, 56, 0x10b981).setInteractive({ useHandCursor: true });
      this.add.text(480, y, '下一关', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);
      nextBtn.on('pointerup', () => {
        const nextIndex = Math.min(this.levelIndex + 1, (window.GENSTORY_LEVELS.length - 1));
        this.scene.start('Match3Scene', { levelIndex: nextIndex });
      });
    } else {
      const retryBtn = this.add.rectangle(480, y, 320, 56, 0xef4444).setInteractive({ useHandCursor: true });
      this.add.text(480, y, '重玩关卡', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);
      retryBtn.on('pointerup', () => this.scene.start('Match3Scene', { levelIndex: this.levelIndex }));
    }

    const selectBtn = this.add.text(120, 440, '选关', { fontSize: '16px', color: '#cbd5e1' }).setInteractive({ useHandCursor: true });
    selectBtn.on('pointerup', () => this.scene.start('LevelSelectScene'));

    const menuBtn = this.add.text(840, 440, '返回菜单', { fontSize: '16px', color: '#cbd5e1' }).setInteractive({ useHandCursor: true }).setOrigin(1,0);
    menuBtn.on('pointerup', () => this.scene.start('MenuScene'));
  }
}
