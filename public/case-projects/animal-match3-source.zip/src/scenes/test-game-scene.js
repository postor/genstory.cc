/**
 * AI image prompt (future asset: player sprite):
 * A friendly small robot hero with a red scarf, readable silhouette, side view, transparent background.
 */
class TestGameScene extends Phaser.Scene {
  constructor() { super("TestGameScene"); }

  preload() {
    // Future image hook: this.load.image("player_sprite", "assets/images/player.png");
    // Future audio hook: this.load.audio("jump_sfx", "assets/audio/jump.ogg");
  }

  create() {
    this.cameras.main.setBackgroundColor("#0f172a");
    this.add.text(32, 28, "测试游戏", { fontSize: "28px", color: "#f8fafc" });
    this.add.text(32, 68, "方向键移动，空格跳跃，Esc 返回菜单", { fontSize: "16px", color: "#cbd5e1" });

    this.player = this.add.circle(150, 360, 22, 0xf97316);
    this.physics.add.existing(this.player);
    this.player.body.setCollideWorldBounds(true);

    this.platforms = this.physics.add.staticGroup();
    for (const [x, y, width] of [[480, 500, 860], [230, 390, 180], [710, 330, 180]]) {
      this.platforms.add(this.add.rectangle(x, y, width, 24, 0x334155));
    }
    this.physics.add.collider(this.player, this.platforms);
    this.cursors = this.input.keyboard.createCursorKeys();
    this.input.keyboard.on("keydown-ESC", () => this.scene.start("MenuScene"));

    // Audio prompt: a short warm synth blip for jumping, clean and loop-free.
  }

  update() {
    const body = this.player.body;
    body.setVelocityX(0);
    if (this.cursors.left.isDown) body.setVelocityX(-260);
    if (this.cursors.right.isDown) body.setVelocityX(260);
    if (this.cursors.space.isDown && body.blocked.down) body.setVelocityY(-560);
  }
}
